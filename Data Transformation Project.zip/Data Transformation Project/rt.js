/* NOTES:
- Condensed B and C into a single method
- Transformations D-G feature same, effective transformation code from Project Document
*/

console.log("Half the number of widgets is " + (4 / 2));
/* FIRST
Given: const record = { prop1: 'yo', prop2: 'dude' }
Transformation Given: const transform = { a: 'prop2', b: 'prop1' }
Return: { a: 'dude', b: 'yo' }
*/
const record = { prop1: 'yo', prop2: 'dude' };
const transform = { a: 'prop2', b: 'prop1' };
function transformation1(dict, transformation_dict)
{
    var result_dict = {};
    var keys = [];
    // keeps track of keys used in given transformation dictionary
    for (var key in transformation_dict)
    {
        if (transformation_dict.hasOwnProperty(key))
            keys.push(key);
    }
    for (var i = 0; i < keys.length; i++)
        result_dict[keys[i]] = dict[transformation_dict[keys[i]]];
    return result_dict;
}

/* A TRANSFORMATION
Given: const name_record = [{
  name1: 'Alice',
  name2: 'Bob',
  name3: 'Jerry',
}]
Return: [{
  firstNameA: 'Alice',
  firstNameB: 'Bob',
  firstNameC: 'Jerry',
  firstNameD: 'default value',
}]
*/
const name_record = [{
    name1: 'Alice',
    name2: 'Bob',
    name3: 'Jerry',
  }];
var letter = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
function transformationA(dict)
{
    var result_dict = {};
    var len = 0;
    var name = "";
    // determines length of given input dictionary
    for(var e in dict)
        if(dict.hasOwnProperty(e))
            len++;
    for (i = 0; i < len; i++) {
        // retrieves different JSON variables each iteration (name1, name2, name3...)
        name = "name" + String(i + 1);
        result_dict["firstName" + letter[i]] = (r) => r.get(name);
    }
    return result_dict;
}

/* B TRANSFORMATION
Given: const name_record = [{
  name1: 'Alice',
  name2: 'Bob',
  name3: 'Jerry',
}]

Return: [{
  names: ['Alice', 'Bob', 'Jerry'],
}]
*/
function transformationB(dict)
{
    var result_dict = {};
    var len = 0;
    // determines length of given input dictionary
    for(var e in dict)
        if(dict.hasOwnProperty(e))
            len++;
    for (i = 0; i < len; i++)
        var name = "name" + String(i + 1);
        var result = "";
        // the last input dictionary value is ran separately to ensure no comma is placed after it
        if (len - 1 == i)
            result += String((r) => r.get(name));
        else
            result += String((r) => r.get(name)) + ", ";
        result_dict["names"] = result;
    return result_dict;
}

/* C TRANSFORMATION
Given: const name_record = [{
  name1: 'Alice',
  name2: 'Bob',
  name3: 'Jerry',
}]

Return: [{
  names: 'Alice-Bob-Jerry',
}]
*/
function transformationC(dict)
{
    var result_dict = {};
    var len = 0;
    // determines length of given input dictionary
    for(var e in dict)
        if(dict.hasOwnProperty(e))
            len++;
    for (i = 0; i < len; i++)
        var name = "name" + String(i + 1);
        var result = "";
        // the last input dictionary value is ran separately to ensure no hyphen is placed after it
        if (len - 1 == i)
            result += String((r) => r.get(name));
        else
            result += String((r) => r.get(name)) + "-";
        result_dict["names"] = result;
    return result_dict;
}

/* BC Condensation TRANSFORMATION
Given: const name_record = [{
  name1: 'Alice',
  name2: 'Bob',
  name3: 'Jerry',
}]

Return: [{
  names: 'Alice-Bob-Jerry',
}]
or [{
  names: ['Alice', 'Bob', 'Jerry'],
}]
*/
function transformationBC(dict,form)
{
    var result_dict = {};
    var len = 0;
    // show error if form is not "," or "-"
    if (form != "," && form != "-")
        throw "Form must be ',' or '-'";
    // determines length of given input dictionary
    for(var e in dict)
        if(dict.hasOwnProperty(e))
            len++;
    for (i = 0; i < len; i++)
        var name = "name" + String(i + 1);
        var result = "";
        // the last input dictionary value is ran separately to ensure no comma or hyphen is placed after it
        if (len - 1 == i)
            result += String((r) => r.get(name));
        else
            if (form == ",")
                result += String((r) => r.get(name)) + ", ";
            else
                result += String((r) => r.get(name)) + "-";
        result_dict["names"] = result;
    return result_dict;
}

/* D TRANSFORMATION
Given: [{
  name: 'Alice',
  addressStreet: '730 Florida St.',
  addressCity: 'San Francisco',
  addressState: 'CA',
}]
Return: [{
  person: {
    name: 'Alice',
    addressHash: 'afa3efbcd1',
  },
  address: {
    hash: 'afa3efbcd1',
    street: '730 Florida',
    city: 'San Francisco',
    state: 'CA',
  },
}]
*/
const address_record = [{
    name: 'Alice',
    addressStreet: '730 Florida St.',
    addressCity: 'San Francisco',
    addressState: 'CA',
  }];
function transformationD(dict)
{
    return {
        person: {
          name: (r) => r.get('name'),
          addressHash: (r) => md5([r.get('addressStreet'), r.get('addressCity'), r.get('addressState')].join('-')),
        },
        address: {
          hash: (r) => md5([r.get('addressStreet'), r.get('addressCity'), r.get('addressState')].join('-')),
          street: (r) => r.get('addressStreet'),
          city: (r) => r.get('addressCity'),
          state: (r) => r.get('addressState'),
        }
      };
}

/* E TRANSFORMATION
Given: [{
  person: {
    name: 'Alice',
  },
  addresses: {
    street: '730 Florida',
    city: 'San Francisco',
    state: 'CA',
  },
}]
Return: [{
  name: 'Alice',
  street: '730 Florida',
  city: 'San Francisco',
  state: 'CA',
}]
*/
const addressFlatten_record = [{
    person: {
      name: 'Alice',
    },
    addresses: {
      street: '730 Florida',
      city: 'San Francisco',
      state: 'CA',
    },
  }];
function transformationE(dict)
{
    return {
        name: 'person.name',
        street: 'address.street',
        city: 'address.city',
        state: 'address.state',
      };
}

/* F TRANSFORMATION
Given: [
  {
    prop1: null,
    prop2: 'non-empty-1',
  },
  {
    prop1: 'non-empty-3',
    prop2: 'non-empty-4',
  },
]
Return: [
  {prop: 'non-empty-1'},
  {prop: 'non-empty-3'},
]
*/
const conditionalMap_record = [
    {
      prop1: null,
      prop2: 'non-empty-1',
    },
    {
      prop1: 'non-empty-3',
      prop2: 'non-empty-4',
    },
  ];
function transformationF(dict)
{
    return {
        prop: (r) => r.get('prop1') || r.get('prop2'),
      };
}

/* G TRANSFORMATION
Given: [{
  stringThing: 'a, b,, c',
}]
Return: [{
  vectorThing: ['A', 'B', 'C'],
}]
*/
const convertChar_record = [{
    stringThing: 'a, b, c',
  }];
function transformationG(dict)
{
    return {
        vectorThing: (r) => r.get('stringThing').split(',').filter((v) => !!v.length).map((v) => v.trim().toUpperCase()),
      };
}

console.log(record["prop1"]);
console.log(transformation1(record,transform));
console.log(transformationA(name_record));
console.log(transformationB(name_record));
console.log(transformationC(name_record));
console.log(transformationBC(name_record, ","));
console.log(transformationBC(name_record, "-"));
// Didn't change given transformation defintions
console.log(transformationD(address_record));
console.log(transformationE(addressFlatten_record));
console.log(transformationF(conditionalMap_record));
console.log(transformationG(convertChar_record));
